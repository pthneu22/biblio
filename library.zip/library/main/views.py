from django.db.models import Q, Count
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

from .forms import OperationForm
from .models import *


def index(request):
    res = Book.objects.all()
    return render(request, 'index.html', {"res": res})


def book_list(request):
    res = Book.objects.all()
    return render(request, 'books.html', {"res": res})


def student_list(request):
    res = Client.objects.all()
    return render(request, 'students.html', {"res": res})


def operations_list(request):
    res = Operation.objects.all()
    return render(request, 'operations.html', {"res": res})


def operation_add(request):
    if request.method == "POST":
        form = OperationForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('operations_list'))
    else:
        form = OperationForm()
    return render(request, 'operation_add.html', {'form': form})


def taked_books(request):
    res = Operation.objects.all().filter(Q(status='У клиента') | Q(status='Просрочено'))
    return render(request, 'taked_books.html', {"res": res})


def popular_book(request):
    res = Operation.objects.all().values('book__name').annotate(dcount=Count('id'))
    print(res)
    return render(request, 'popular_books.html', {"res": res})

