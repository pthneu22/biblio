from django import forms
from main.models import Operation


class DateInput(forms.DateInput):
    input_type = 'date'


class OperationForm(forms.ModelForm):
    class Meta:
        model = Operation
        fields = ('__all__')
        widgets = {'dat': DateInput}

