from django.db import models


class Author(models.Model):
    name = models.CharField('Автор', max_length=200)

    class Meta:
        verbose_name = 'Автор'
        verbose_name_plural = 'Авторы'

    def __str__(self):
        return self.name


class Izdatelstvo(models.Model):
    name = models.CharField('Название', max_length=200)

    class Meta:
        verbose_name = 'Издательство'
        verbose_name_plural = 'Издательства'

    def __str__(self):
        return self.name


class Book(models.Model):
    name = models.CharField('Название', max_length=200)
    author = models.ForeignKey(Author, verbose_name='Автор', on_delete=models.CASCADE)
    izdatelstvo = models.ForeignKey(Izdatelstvo, verbose_name='Издательство', on_delete=models.CASCADE)
    price = models.IntegerField('Цена')
    cnt = models.IntegerField('Количество')
    year = models.IntegerField('Год')

    class Meta:
        verbose_name = 'Книга'
        verbose_name_plural = 'Книги'

    def __str__(self):
        return self.name


class Client(models.Model):
    fio = models.CharField('ФИО', max_length=200)
    address = models.CharField('Адрес', max_length=200)
    phone = models.CharField('Телефон', max_length=200)

    class Meta:
        verbose_name = 'Клиент'
        verbose_name_plural = 'Клиенты'

    def __str__(self):
        return self.fio


class Operation(models.Model):
    STATUSES = (
        ('Просрочено', 'Просрочено'),
        ('У клиента', 'У клиента'),
        ('В наличии', 'В наличии'),
    )
    client = models.ForeignKey(Client, verbose_name='Клиент', on_delete=models.CASCADE)
    book = models.ForeignKey(Book, verbose_name='Книга', on_delete=models.CASCADE)
    dat = models.DateField("Дата операции")
    srok = models.IntegerField('Срок (в днях)')
    status = models.CharField('Статус', choices=STATUSES, default='В наличии', max_length=50)
