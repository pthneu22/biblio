from django.urls import path
from .views import *


urlpatterns = [
    path('', index, name='main_page'),
    path('books/', book_list, name='book_list'),
    path('students/', student_list, name='student_list'),
    path('operations/', operations_list, name='operations_list'),
    path('operation_add/', operation_add, name='operation_add'),
    path('taked_books/', taked_books, name='taked_books'),
    path('popular_book/', popular_book, name='popular_book'),
]
