from django.contrib import admin
from .models import *


@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Izdatelstvo)
class IzdatelstvoAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['name', 'author', 'izdatelstvo', 'price', 'cnt', 'year']


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ['fio', 'address', 'phone']


@admin.register(Operation)
class OperationAdmin(admin.ModelAdmin):
    list_display = ['client', 'book', 'dat', 'srok', 'status']

